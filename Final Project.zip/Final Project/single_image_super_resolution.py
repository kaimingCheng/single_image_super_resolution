"""
Implements fully connected networks in PyTorch.
WARNING: you SHOULD NOT use ".to()" or ".cuda()" in each implementation block.
"""

from posix import GRND_NONBLOCK
import torch
from torch._C import ScriptModuleSerializer
import torch
from torch import Tensor, nn, optim
from torch.nn import functional as F
from torch.nn.modules.dropout import Dropout
import h5py
import numpy as np
from torch.utils.data import Dataset
from PIL import Image
import os
import cv2
import time
import math
import matplotlib.pyplot as plt
import skimage


def hello():
    """
    This is a sample function that we will try to import and run to ensure that
    our environment is correctly set up on Google Colab.
    """
    print('Hello from single_image_super_resolution.py!')


def load_training_samples(path = '/content/drive/My Drive/General-100/'):
    """
    This is a function used to load the original images.
    """
    training_set = {}
    list_dir = os.listdir(path)
    for i in range(len(list_dir)):
      pic = Image.open(os.path.join(path, list_dir[i]))
      img = np.array(pic)
      training_set[i] = img
    return training_set


def sub_image(train, f_sub=33, stride=14, scale_factor=2):
    """
    This is a function used to generate sub-images from our original training 
    samples. The ground truth images {Xi} are prepared as f_sub×f_sub×c-pixel 
    sub-images randomly cropped from the training images. After that we also 
    implement a bluring and down-sampling for the subimages to create a training
    pairs.
    """
    n = len(train)
    data_dict = {}
    temp = []
    for k in range(n):
      for i in range(0, train[k].shape[0], stride):
        for j in range(0, train[k].shape[1], stride):
          cropped = train[k][i:i+f_sub, j:j+f_sub, :]
          down_sampled = image_blur_down_sample(cropped, scale_factor=scale_factor)
          # down_sampled = np.expand_dims(down_sampled, 2)
          temp.append([cropped, down_sampled])
    for i in range(len(temp)):
      data_dict[i] = temp[i]
    return data_dict


def image_blur_down_sample(x, kernel_size=5, scale_factor=2):
    """
    This is a function used to synthesize the training inputs, which are the 
    lower-resolution images. We first blur a sub-image by a Gaussian kernel,
    then sub-sample it by the upscaling factor.
    """
    Gaussian = cv2.GaussianBlur(x, (kernel_size, kernel_size), 0)
    down_sampled = Gaussian[0::scale_factor, 0::scale_factor]
    # down_sampled = 
    return down_sampled


def bilinear_interpolation(x, scale_factor=2):
    """
    This is a function for bicubic interpolation, the final output is our input 
    to the network.
    """
    res = cv2.resize(x, None, fx=scale_factor, fy=scale_factor, interpolation = cv2.INTER_LINEAR)
    # res = skimage.transform.resize(x, order=3)
    return res


def bicubic_interpolation(x, scale_factor=2):
    """
    This is a function for bicubic interpolation, the final output is our input 
    to the network.
    """
    res = cv2.resize(x, None, fx=scale_factor, fy=scale_factor, interpolation = cv2.INTER_CUBIC)
    # res = skimage.transform.resize(x, order=3)
    return res


def data_dict_transform(train_inter_pairs, fsub=34):
    """
    This is a function for turn the data_dict into a numpy array like object
    """
    data_dict = {}
    k = 0
    for i in range(len(train_inter_pairs)):
      if (train_inter_pairs[i][1].shape[0] == fsub) & (train_inter_pairs[i][1].shape[1] == fsub) & (train_inter_pairs[i][0].shape[0] == fsub) & (train_inter_pairs[i][0].shape[1] == fsub):
        k += 1
    data_dict['X_train'] = torch.ones(k, fsub, fsub, 1)
    data_dict['y_train'] = torch.ones(k, fsub, fsub, 1)
    k = -1
    for i in range(len(train_inter_pairs)):
      if (train_inter_pairs[i][1].shape[0] == fsub) & (train_inter_pairs[i][1].shape[1] == fsub) & (train_inter_pairs[i][0].shape[0] == fsub) & (train_inter_pairs[i][0].shape[1] == fsub):
        k += 1
        data_dict['X_train'][k, :] = train_inter_pairs[i][1].unsqueeze(2)
        data_dict['y_train'][k, :] = train_inter_pairs[i][0]
    data_dict['X_train'] = data_dict['X_train'].permute(0, 3, 1, 2)
    data_dict['y_train'] = data_dict['y_train'].permute(0, 3, 1, 2)
    return data_dict


def data_dict_transform_fsrcnn(train_inter_pairs, fsub=34):
    """
    This is a function for turn the data_dict into a numpy array like object
    """
    data_dict = {}
    k = 0
    for i in range(len(train_inter_pairs)):
      if (train_inter_pairs[i][1].shape[0] == 17) & (train_inter_pairs[i][1].shape[1] == 17) & (train_inter_pairs[i][0].shape[0] == fsub) & (train_inter_pairs[i][0].shape[1] == fsub):
        k += 1
    data_dict['X_train'] = torch.ones(k, 17, 17, 1)
    data_dict['y_train'] = torch.ones(k, fsub, fsub, 1)
    k = -1
    for i in range(len(train_inter_pairs)):
      if (train_inter_pairs[i][1].shape[0] == 17) & (train_inter_pairs[i][1].shape[1] == 17) & (train_inter_pairs[i][0].shape[0] == fsub) & (train_inter_pairs[i][0].shape[1] == fsub):
        k += 1
        data_dict['X_train'][k, :] = train_inter_pairs[i][1].unsqueeze(2)
        data_dict['y_train'][k, :] = train_inter_pairs[i][0]
    data_dict['X_train'] = data_dict['X_train'].permute(0, 3, 1, 2)
    data_dict['y_train'] = data_dict['y_train'].permute(0, 3, 1, 2)
    return data_dict


def train_val_split(data_dict):
    """
    This is a function for train validation split.
    """
    n = len(data_dict['X_train'])
    train_idx = np.random.choice(n, int(0.8*n), replace=False, p=None)
    val_idx = list(set(np.arange(n)) - set(train_idx))
    data_dict['X_train'], data_dict['X_val'] = data_dict['X_train'][train_idx], data_dict['X_train'][val_idx]
    data_dict['y_train'], data_dict['y_val'] = data_dict['y_train'][train_idx], data_dict['y_train'][val_idx]


class SRCNN(nn.Module):
    """
    Class for SRCNN
    """
    def __init__(self, num_channels=1, n1=64, n2=32, f1=9, f2=1, f3=5, pad=True):
        super().__init__()
        if pad == True:
          self.conv1 = nn.Conv2d(num_channels, n1, kernel_size=f1, padding=f1 // 2)
          self.conv2 = nn.Conv2d(n1, n2, kernel_size=f2, padding=f2 // 2)
          self.conv3 = nn.Conv2d(n2, num_channels, kernel_size=f3, padding=f3 // 2)
        else:
          self.conv1 = nn.Conv2d(num_channels, n1, kernel_size=f1)
          self.conv2 = nn.Conv2d(n1, n2, kernel_size=f2)
          self.conv3 = nn.Conv2d(n2, num_channels, kernel_size=f3)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.conv3(x)
        return x


class FSRCNN(nn.Module):
    """
    Class for FSRCNN
    """
    def __init__(self, num_channels=1, s=12, d=56, m=4, scale=2, pad=True):
        super().__init__()
        if pad == True:
          self.conv1 = nn.Conv2d(num_channels, d, kernel_size=5, padding=5 // 2)
          self.conv2 = nn.Conv2d(d, s, kernel_size=1, padding=1 // 2)
          layers = []
          for i in range(m):
            layers.append(nn.Conv2d(s, s, kernel_size=3, padding=3 // 2))
          self.conv3 = nn.Sequential(*layers) 
          self.conv4 = nn.Conv2d(s, d, kernel_size=1, padding=1 // 2)
          self.conv5 = nn.ConvTranspose2d(d, num_channels, kernel_size=8, stride=scale, padding=7//2)
        else:
          self.conv1 = nn.Conv2d(num_channels, d, kernel_size=5)
          self.conv2 = nn.Conv2d(d, s, kernel_size=1)
          layers = []
          for i in range(m):
            layers.append(nn.Conv2d(s, s, kernel_size=3))
          self.conv3 = nn.Sequential(*layers) 
          self.conv4 = nn.Conv2d(s, d, kernel_size=1)
          self.conv5 = nn.ConvTranspose2d(d, num_channels, kernel_size=9, stride=2)
        self.prelu = nn.PReLU()

    def forward(self, x):
        x = self.prelu(self.conv1(x))
        x = self.prelu(self.conv2(x))
        x = self.prelu(self.conv3(x))
        x = self.prelu(self.conv4(x))
        x = self.conv5(x)
        return x


def train_srcnn(
    image_data,
    data_eval,
    model=SRCNN(),
    num_epochs=1,
    batch_size=32,
    learning_rate=5e-5,
    criterion = nn.MSELoss(),
    method = 'srcnn',
    scale=2,
    path = 'srcnn.pth',
    device: torch.device = torch.device("cuda"),
):
    X_train = image_data['X_train']
    y_train = image_data['y_train']
    print("Training started...")

    if method == 'srcnn':
      model = SRCNN().to(device)
    elif method == 'fsrcnn':
      model = FSRCNN().to(device)
    # criterion = nn.MSELoss()
    # optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    loss_history = []
    val_loss_history = []
    psnr_history = []
    optimizer = torch.optim.Adam(
            model.parameters(), lr=learning_rate, betas=(0.9, 0.995), eps=1e-9
        )
    iteration = 0
    num_train = X_train.shape[0]
    for epoch_num in range(num_epochs):
        epoch_loss = []
        model.train()
        idx = torch.randperm(num_train)
        for i in range(num_train//batch_size):
            # num_train = X_train.shape[0]
            batch_mask = idx[i*batch_size: i*batch_size+batch_size]
            X_batch = X_train[batch_mask].to(device)
            y_batch = y_train[batch_mask].to(device)
            # inp, inp_pos, out, out_pos = it
            model = model.to(device)
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            # inp_pos = inp_pos.to(device)
            # out_pos = out_pos.to(device)
            # out = out.to(device)
            # inp = inp.to(device)
            # gnd = 
            optimizer.zero_grad()

            # pred = model(inp.long(), inp_pos, out.long(), out_pos)
            gnd = y_batch
            pred = model(X_batch)
            loss = criterion(pred, gnd)
            epoch_loss.append(loss.item())
            loss_history.append(loss.item())

            loss.backward()
            optimizer.step()
            iteration = iteration + 1
            
            psnr_history.append(average_psnr(model, data_eval, scale=scale, method=method))
            

        avg_epoch_loss = sum(epoch_loss) / len(epoch_loss)
        val_loss, val_hist = val(model, image_data, criterion, batch_size)
        loss_hist = avg_epoch_loss / (batch_size)
        val_loss_history += val_hist
        print(
            f"[epoch: {epoch_num+1}]",
            "[loss: ",
            f"{loss_hist:.4f}",
            "]",
            "val_loss: [val_loss ",
            f"{val_loss:.4f}",
            "]",
        )
    plt.plot(loss_history)
    # plt.plot(val_loss_history)
    plt.xlabel("Iteration")
    plt.ylabel("Loss")
    plt.title("Training loss history")
    plt.show()

    plt.plot(psnr_history)
    # plt.plot(val_loss_history)
    plt.xlabel("Iteration")
    plt.ylabel("Average PSNR")
    plt.title("Average PSNR history")
    plt.show()

    # if method == 'srcnn':
    #   torch.save(model, '/content/drive/My Drive/Final Project/srcnn'+str(scale)+'.pth')
    # elif method == 'fsrcnn':
    #   torch.save(model, '/content/drive/My Drive/Final Project/fsrcnn'+str(scale)+'.pth')
    torch.save(model, '/content/drive/My Drive/Final Project/'+path)

    return model


def val(model, dataloader, loss_func, batch_size, device=torch.device("cuda")):
    model.eval()
    epoch_loss = []
    num_correct = 0
    total = 0
    X_val = dataloader['X_val']
    y_val = dataloader['y_val']
    num_val = X_val.shape[0]
    for i in range(num_val//batch_size):
        batch_mask = torch.randperm(num_val)[: batch_size]
        X_batch = X_val[batch_mask].to(device)
        y_batch = y_val[batch_mask].to(device)
        # inp, inp_pos, out, out_pos = it
        model = model.to(device)
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        # pred = model(inp.long(), inp_pos, out.long(), out_pos)
        gnd = y_batch
        pred = model(X_batch)
        loss = loss_func(pred, gnd)
        epoch_loss.append(loss.item())

    avg_epoch_loss = sum(epoch_loss) / len(epoch_loss)
    return avg_epoch_loss / (batch_size), epoch_loss


def evaluate(lr, model, scale=2, method='srcnn'):
      """
      This is a function for evaluating and testing.
      The input is a low-resolution image in format of Image object and a model, 
      and the output is the corresponding super-resolution image with the model.
      """

      img = np.array(lr)
      if method == 'srcnn':
        img = bicubic_interpolation(img, scale)
        y = skimage.color.rgb2ycbcr(img)[:, :, 0]
        cbcr = skimage.color.rgb2ycbcr(img)[:, :, 1:3]
      elif method == 'fsrcnn':
        y = skimage.color.rgb2ycbcr(img)[:, :, 0]
        img = bicubic_interpolation(img, scale)
        cbcr = skimage.color.rgb2ycbcr(img)[:, :, 1:3]
      # y = np.expand_dims(y, 2)
      y = torch.tensor(y, dtype=torch.float32)
      H, W = y.shape
      y = y.view(1, 1, H, W)
      y = y.to('cuda')
      out_y = model(y)
      if method == 'srcnn':
        out_y = out_y.view(H, W, 1)
      elif method == 'fsrcnn':
        out_y = out_y.view(scale*H, scale*W, 1)
      out_y = np.array(out_y.detach().cpu())
      output = np.concatenate((out_y, cbcr), axis=2)
      output = skimage.color.ycbcr2rgb(output)
      output *= 255
      output = np.clip(output, 0.0, 255.0).astype(np.uint8)
      
      return output


def evaluate_metric(hr, lr, model, metric='psnr', scale=2, method='srcnn'):
      """
      This is a function for evaluating and testing.
      The input is a low-resolution image in format of numpy array, a ground-turth
      super-resolution image and a model, the output is the PSNR or SSIM of 
      corresponding super-resolution image with model and the original ground-turth
      super-resolution image
      """

      # img = np.array(lr)
      if method == 'srcnn':
        lr = bicubic_interpolation(lr, scale)
      y = skimage.color.rgb2ycbcr(lr)[:, :, 0]
      # cbcr = skimage.color.rgb2ycbcr(img)[:, :, 1:3]
      # y = np.expand_dims(y, 2)
      y = torch.tensor(y, dtype=torch.float32)
      H, W = y.shape
      y = y.view(1, 1, H, W)
      y = y.to('cuda')
      out_y = model(y)
      # print(out_y.shape)
      if method == 'fsrcnn':
        H, W = hr.shape[0], hr.shape[1]
      out_y = out_y.view(H, W, 1)
      out_y = np.array(out_y.detach().cpu())
      # output = np.concatenate((out_y, cbcr), axis=2)
      # output = skimage.color.ycbcr2rgb(output)
      # output *= 255
      out_y = np.clip(out_y, 0.0, 255.0)
      hr_y = skimage.color.rgb2ycbcr(hr)[:, :, 0]
      hr_y = np.expand_dims(hr_y, 2)
      hr_y /= 255
      out_y /= 255
      hr_y = hr_y.astype(np.float32)
      if metric == 'psnr':
        score = skimage.metrics.peak_signal_noise_ratio(hr_y, out_y)
      elif metric == 'ssim':
        score = skimage.metrics.structural_similarity(hr_y, out_y, multichannel=True)

      return score


def load_evaluation_set(scale=2, form='LR'):
    """
    This is a function for loading evaluation set. It returns a dictionary 
    with key from 1 to 19 and value the corresponding image in Set5 and Set14.
    """
    root5 = '/content/drive/My Drive/Set5_SR/Set5/' + 'image_SRF_' + str(scale)
    root14 = '/content/drive/My Drive/Set14_SR/Set14/' + 'image_SRF_' + str(scale)
    data_dict = {}

    list_dir = os.listdir(root5)
    
    for i in range(len(list_dir)):
        if list_dir[i].split('.')[0].split('_')[-1] == form:
          pic = Image.open(os.path.join(root5, list_dir[i]))
          img = np.array(pic)
          k = int(list_dir[i].split('.')[0].split('_')[1][-1])
          data_dict[k] = img
          
    
    list_dir = os.listdir(root14)
    for i in range(len(list_dir)):
        if list_dir[i].split('.')[0].split('_')[-1] == form:
          pic = Image.open(os.path.join(root14, list_dir[i]))
          img = np.array(pic)
          k = int(list_dir[i].split('.')[0].split('_')[1][1:])+5
          # print(k)
          if len(img.shape) == 2:
            img = np.concatenate((np.expand_dims(img, 2), np.expand_dims(img, 2), np.expand_dims(img, 2)), axis=2)
          data_dict[k] = img
          

    return data_dict


def average_psnr(model, data_eval, scale=2, metric='psnr', method='srcnn'):
    """
    This is a function for calculating average PSNR score.
    """
    average = 0
    for i in range(19):
      hr = data_eval['hr_' + str(scale)][i+1]
      lr = data_eval['lr_' + str(scale)][i+1]
      average += evaluate_metric(hr, lr, model, metric=metric, scale=scale, method=method)
    average /= 19
    return average


def y(img):
    """
    This is a function for getting the first channel of the YCbCr color space.
    """
    return skimage.color.rgb2ycbcr(img)[:, :, 0]/255


def plot_set(i, path, scale=2):
    """
    This is a function for plotting a set of images in Set5.
    It will plot from left to right the super-resolution image, low-resolution 
    input, bilinear interpolation output, bicubic interpolation output and the 
    model output. Here I only use SRCNN since FSRCNN generally has the same 
    super-resolution effect except the short training duration.
    """

    figure, axis = plt.subplots(1, 5)
    model = torch.load(path)
    model.eval()
    gt = Image.open('/content/drive/My Drive/Set5_SR/Set5/image_SRF_'+str(scale)+'/img_00'+str(i)+'_SRF_'+str(scale)+'_HR.png')
    lr = Image.open('/content/drive/My Drive/Set5_SR/Set5/image_SRF_'+str(scale)+'/img_00'+str(i)+'_SRF_'+str(scale)+'_LR.png')
    out = evaluate(lr, model, scale=scale, method='srcnn')
    img_gt = np.array(gt)
    img_lr = np.array(lr)
    img_li = bilinear_interpolation(img_lr, scale)
    img_cu = bicubic_interpolation(img_lr, scale)
    axis[0].imshow(img_gt)
    axis[0].title.set_text('SR')
    axis[1].imshow(img_lr)
    axis[1].title.set_text('LR')
    axis[2].imshow(img_li)
    axis[2].title.set_text('Bilinear')
    axis[3].imshow(img_cu)
    axis[3].title.set_text('Bicubic')
    axis[4].imshow(out)
    axis[4].title.set_text('srcnn')
    plt.show()
    score = []
    score.append(skimage.metrics.peak_signal_noise_ratio(y(img_gt), y(img_li)))
    score.append(skimage.metrics.peak_signal_noise_ratio(y(img_gt), y(img_cu)))
    score.append(skimage.metrics.peak_signal_noise_ratio(y(img_gt), y(out)))
    score.append(skimage.metrics.structural_similarity(y(img_gt), y(img_li), multichannel=True))
    score.append(skimage.metrics.structural_similarity(y(img_gt), y(img_cu), multichannel=True))
    score.append(skimage.metrics.structural_similarity(y(img_gt), y(out), multichannel=True))

    return score

    





